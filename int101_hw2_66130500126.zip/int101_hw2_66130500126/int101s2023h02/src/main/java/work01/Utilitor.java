package work01;

public class Utilitor {
    
    public static String testString(String value) {
        if (value.equals(null)) {
            throw new NullPointerException();
        } else if (value.isBlank()) {
            throw new IllegalArgumentException();
        }
        return value;
    }
    
    public static double testPositive(double value) {
        if (value > 0) {
            return value;
        }
        throw new IllegalArgumentException();
    }
    
    public static long computeIsbn10(long isbn10) {
        
        int a = 9; //min 2 max 9
        int b = 10;
        int sum = 0;
        StringBuilder kk = new StringBuilder();
        for (int i = 0; i < 9; i++) {
            long next = isbn10 % (long) Math.pow(10, a - 1);
            long num = (isbn10 - next);
            long naw = num / (long) Math.pow(10, a - 1);
            kk.append(naw);
            
            //System.out.println(naw);
            sum += naw * b;
            isbn10 = next;
            b--;
            a--;
        }
        long lastnum = 11 - sum % 11;
        kk.append(lastnum);
        
        long asd = Long.parseLong(kk.toString());
        
        return asd;
    }
}
