package work03;

import work01.Utilitor;
import work02.Person;

public class Account {

    private static long nextNo = 1_000_000_000;
    private final long no;
    private Person owner;
    private double balance;

    public Account(Person owner) {
        if (owner == null) {
            throw new NullPointerException();
        }
        this.balance = 0.0;
        this.owner = owner;

        long result = Utilitor.computeIsbn10(nextNo);

        while (result == 10) {

            result = Utilitor.computeIsbn10(nextNo++);
        }
        this.no = 10 * nextNo + result;

    }

    public long getNo() {
        return no;
    }

    public Person getOwner() {
        return owner;
    }

    public double getBalance() {
        return balance;
    }

    public double deposit(double amount) {

        Utilitor.testPositive(amount);
        return balance += amount;
    }

    public double withdraw(double amount) {
        Utilitor.testPositive(amount);
        return balance -= amount;
    }

    public void transfer(double amount, Account account) {
        if (account == null) {
            throw new IllegalArgumentException();
        }
        Utilitor.testPositive(amount);
        withdraw(amount);
        account.deposit(amount);

    }

    @Override
    public String toString() {

        return "Account(" + no + "," + balance + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }


        return false;
 

    }
}
