package work02;

import work01.Utilitor;


public class Person {
    private static int nextId = 1;
    private final int id;
    private String firstname;
    private String lastname;
    
    
    
    
    public Person(String firstname,String lastname) {
        this.firstname = Utilitor.testString(firstname);
        this.lastname = Utilitor.testString(lastname);

        this.id = nextId++;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setFirstname(String firstname) {
        this.firstname = Utilitor.testString(firstname);;
        
    }

    public void setLastname(String lastname) {
        this.lastname = Utilitor.testString(lastname);;
    }

    public int getId() {
        return id;
    }
    
    
    @Override
    
    public String toString(){
    StringBuilder ans = new StringBuilder();
    ans.append("Person(");
    ans.append(this.id);
    ans.append(",");
    ans.append(this.firstname);
    ans.append(",");
    ans.append(this.lastname);
    ans.append(")");
   return ans.toString();

}

    @Override
    public boolean equals(Object obj){
       return this == obj;
    }

    
    
    
}



